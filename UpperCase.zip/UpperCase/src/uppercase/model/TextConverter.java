package uppercase.model;

public interface TextConverter {
    String toUpperCase(String text);
}